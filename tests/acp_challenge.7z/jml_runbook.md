Joiner–Mover–Leaver Lifecycle Management Runbook
(ISO / IEC 27001:2022 Control Reference: A.5.16, A.5.18)

Document Metadata
Field	Value
Document ID	MS-RB-JML-001
Version	1.0
Effective Date	2025-11-07
Owner	HR Operations & Identity Engineering
Author	(ChatGPT5 via Morphic Core overlay v1.7.5b & Edward Levin)
Review Cycle	Annual
Classification	Internal Use Only
Approved By	Chief Information Security Officer (CISO)
Scope	Global workforce and contractor identity lifecycle across Entra ID, Workday, and ServiceNow
1. Purpose

This document defines the operational procedures for managing user identity lifecycles (Joiner–Mover–Leaver) across Microsoft systems, ensuring compliance with ISO/IEC 27001:2022 Annex A controls A.5.16 (Identity Management) and A.5.18 (Access Rights Management).

The objectives are to:

Guarantee consistent, traceable, and timely account provisioning and deprovisioning.

Prevent accumulation of obsolete access rights.

Ensure all identity events are auditable and verifiable.

2. Roles and Responsibilities
Role	Responsibility
HR Operations	Initiates identity lifecycle events (hire, transfer, termination) in Workday.
Identity Engineering	Automates provisioning/deprovisioning via Entra ID and SCIM integrations.
Manager / Supervisor	Approves access requests and validates business justification.
Security Engineering (IAM)	Maintains provisioning logic and ensures system synchronization.
ServiceNow GRC	Tracks approvals and creates audit evidence.
CISO / GRC Oversight	Reviews compliance metrics quarterly.
3. Process Overview

All identity changes flow through Workday → ServiceNow → Entra ID / Azure AD → Application systems.
Each stage generates immutable audit events stored in Azure Monitor and ServiceNow.

4. Joiner Workflow

Trigger: HRIS hire event or contract creation in Workday.

Steps:

HR creates or rehires employee record in Workday.

Workday triggers SCIM provisioning to Entra ID (SCIM API v2).

Entra ID assigns baseline groups:

Corporate M365 access (Exchange, Teams, SharePoint).

Security Baseline Conditional Access group.

Assigned department and region-specific access.

Manager receives ServiceNow ticket for confirmation within 24 hours.

Account verified and activated; MFA enrollment required before first login.

Default license assignment (M365 E5) applied.

SLAs:

Account provisioning completed ≤ 24 hours from HR trigger.

MFA activation required within first login session.

Evidence:

ServiceNow Ticket

Azure AD Provisioning Logs

MFA Enrollment Report

5. Mover Workflow

Trigger: Employee transfer, promotion, or department change in Workday.

Steps:

HR updates Workday with new position.

ServiceNow generates Mover event ticket.

System auto-removes old role groups using attribute-driven automation.

New access rights assigned based on updated role and manager approval.

SOC verifies access differential (removed vs. added).

Manager receives access summary for attestation.

SLAs:

Access alignment completed ≤ 24 hours post HR update.

Evidence:

JML Mover Report (ServiceNow)

Attribute Change Logs (Azure AD)

Attestation Confirmation (Email / Portal)

6. Leaver Workflow

Trigger: Termination, contract expiration, or long-term leave notice in Workday.

Steps:

HR termination in Workday triggers deprovisioning workflow.

ServiceNow disables account immediately and removes all group memberships.

Tokens revoked via Azure AD PowerShell and Graph API.

Intune and device access wiped (corporate data container).

SOC verifies revocation through Sentinel correlation.

Account deletion after retention (90 days) unless legal hold applies.

SLAs:

Account disabled immediately upon HR termination.

Device wipe within 4 hours.

Token revocation ≤ 15 minutes from trigger.

Evidence:

Deprovisioning Logs (ServiceNow)

Azure AD Token Revocation Report

SOC Correlation Report

7. Audit and Metrics

Joiner SLA Compliance: ≥ 99 %

Mover SLA Compliance: ≥ 98 %

Leaver SLA Compliance: 100 %

Non-compliance: Auto-notification to CISO Dashboard.

Audit Logs: Retained ≥ 3 years in Azure Monitor.

8. Exceptions

Manual onboarding for offline contractors permitted only with CISO approval.

Exceptions documented in ServiceNow with expiration ≤ 30 days.

9. References

Access Control Policy – Sections 5 & 14

ISO/IEC 27001:2022 A.5.16, A.5.18

ServiceNow Automation Workflows

Workday–Entra ID SCIM Configuration Documentation

End of JML Runbook