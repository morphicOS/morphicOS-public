Access Control Policy (ACP) — Microsoft Corporation (Demonstration Draft)

Document ID: MS-SEC-ACP-001
Version: 1.0
Effective Date: 2025-11-07
Authors: (ChatGPT5 via Morphic Core overlay v1.7.5b & Edward Levin)
Standard: ISO / IEC 27001:2022 – Annex A Controls (A.5.1 – A.8.28)
Scope: Microsoft Corporation (ISMS Demonstration – Enterprise Coverage)
Classification: Internal Use / Demonstration Draft Only

1 Governance & Policy Framework
1.1 Purpose

This Access Control Policy establishes the principles, requirements, and responsibilities governing how Microsoft Corporation manages and controls access to its information assets, systems, applications, networks, and facilities. It ensures compliance with ISO / IEC 27001:2022 Annex A controls and Microsoft’s Information Security Management System (ISMS) objectives.

1.2 Objectives

Protect the confidentiality, integrity, and availability of Microsoft information assets.

Define a consistent access control framework across enterprise, cloud, and product environments.

Establish governance for identity lifecycle management and privileged access.

Ensure compliance with legal, contractual, and regulatory requirements applicable to Microsoft’s global operations.

Support continuous improvement through monitoring and internal audit.

1.3 Alignment and Integration

This policy is aligned with:

ISO / IEC 27001:2022 and Annex A controls (A.5 – A.8).

Microsoft Security Development Lifecycle (SDL) and Corporate Security Policy Framework.

Microsoft Information Protection Program (classification and data handling).

Azure and Entra Security Baselines, Microsoft Security Baseline for Windows and M365.

Privileged Access Strategy (PAS) and Zero Trust Architecture (ZTA) framework.

1.4 Governance Structure
Role	Responsibility
Corporate CISO	Policy owner and executive sponsor; approves exceptions and ensures alignment with enterprise risk appetite.
Global Security Organization (GSO)	Implements policy controls across business units; coordinates audits.
Business Unit Security Officers (BUSOs)	Adapt and enforce controls for specific environments (e.g., Cloud, Devices, Engineering).
Legal & Compliance Team	Ensures alignment with privacy, data protection, and regulatory requirements.
Internal Audit (ISMS Audit Function)	Verifies policy compliance and effectiveness through scheduled audits.
Change Control Board (CCB)	Reviews and approves major policy updates.
1.5 Policy Review and Maintenance

This policy is reviewed annually or upon material changes to Microsoft’s security architecture, technology stack, or business operations.

Reviews include CISO approval, Legal input, and Internal Audit validation.

All revisions are tracked in Microsoft’s Corporate Policy Repository and tagged with revision history.

2 Scope and Applicability
2.1 Organizational Scope

This policy applies to all Microsoft business units, subsidiaries, and affiliated entities that operate under the Microsoft Information Security Management System (ISMS). It covers:

Corporate environments (Microsoft 365, Teams, SharePoint, Exchange Online).

Engineering environments (Azure, GitHub Enterprise, DevOps, Visual Studio Services).

Production and datacenter environments (Azure production infrastructure and regional datacenters).

Corporate devices (Intune-enrolled endpoints and BYOD containers).

Third-party contractors, vendors, and partners with access to Microsoft systems or data.

Physical facilities and secured offices.

2.2 Information and Asset Scope

This policy covers access to all information classified as: Public, Internal, Confidential, and Highly Confidential. Systems in scope include:

Azure and M365 cloud services.

On-premises and hybrid infrastructure (SCOM, AD, network devices).

End-user devices (Windows, macOS, mobile).

Code repositories, build systems, and CI/CD pipelines.

Support and operations tools (ServiceNow, PagerDuty, Sentinel).

Datacenter access systems and physical security devices.

2.3 Exclusions

Independent subsidiaries with separate ISMS governance must implement equivalent access controls.

Consumer services (e.g., Xbox Live, LinkedIn) follow dedicated security frameworks but maintain alignment with the principles defined here.

3 Access Control Objectives

Microsoft’s access control objectives derive from ISO 27001 Annex A domain A.5 through A.8. They ensure a consistent and measurable approach to managing access risk.

Objective	Control Intent	Key Metrics
Least Privilege	Users receive only the minimum access necessary to perform their roles.	% of roles aligned to least-privilege baseline; # of excess rights revoked.
Segregation of Duties (SoD)	No single individual can initiate and approve a critical transaction or deployment.	SoD violation rate; number of exceptions approved.
Accountability	All actions are traceable to unique identities.	% of shared accounts eliminated; audit log coverage.
MFA & Authentication Strength	All interactive logons use MFA (FIDO2/WebAuthn preferred).	MFA adoption rate; MFA bypass incidents.
Timely Provisioning and Revocation	Accounts provisioned and removed per JML SLA.	Joiner/Mover/Leaver SLA adherence; inactive accounts > 30 days.
Monitoring and Review	All privileged and sensitive access is logged and reviewed periodically.	Access review completion rate; anomalies detected.
4 Roles and Responsibilities
4.1 Executive Leadership

Chief Information Security Officer (CISO):

Owns this policy and approves all exceptions.

Reports access control effectiveness to the Audit Committee and Board Risk Committee.

Sponsors Zero Trust adoption and identity governance programs.

Chief Privacy Officer (CPO):

Ensures alignment with data protection and privacy laws (GDPR, CCPA, etc.).

Chief Information Officer (CIO):

Oversees technical implementation across enterprise infrastructure and applications.

4.2 Operational Functions
Function	Responsibility
Security Engineering	Designs and implements IAM, PAM, and Zero Trust controls; maintains Azure PIM policies.
IT Operations	Manages corporate directory services, Intune, endpoint security, and access provisioning.
Cloud Platform Team	Implements Azure role assignments, subscription segmentation, and network access policies.
Development & Engineering Leads	Define RBAC for applications and repositories; enforce SoD in DevOps pipelines.
Service Owners	Approve access requests for their systems and perform quarterly recertifications.
HR	Provides authoritative data for Joiner/Mover/Leaver events via Workday.
Procurement / Vendor Management	Ensures third-party agreements include access control and audit clauses.
Internal Audit / GRC	Validates control implementation and retains evidence for ISMS audits.
4.3 End Users

All Microsoft employees and contractors must:

Use their assigned corporate identity for all access; no shared accounts.

Protect authentication factors (passwords, keys, tokens).

Comply with least-privilege principles and report suspected misuse.

Complete mandatory annual security training.

5 Identity and Access Management (IAM)
5.1 Authoritative Sources

Human Resources Information System (Workday) is the source of truth for all workforce identity attributes.

Entra ID (formerly Azure Active Directory) serves as Microsoft’s central Identity Provider (IdP) for workforce authentication, single sign-on (SSO), and conditional access.

Active Directory Domain Services (AD DS) remains authoritative for legacy on-premises systems; all new applications must integrate via Entra ID.

Service accounts, bots, and non-person identities are recorded in the Service Account Registry (SAR) maintained by Security Engineering.

Annex A: A.5.16 – Identity Management

5.2 Identity Lifecycle Management

All identities follow the Joiner–Mover–Leaver (JML) process:

Joiner: HR record → automatic Entra ID provisioning → baseline access via group membership.

Mover: Access rights updated within 24 hours of role change; redundant rights revoked first.

Leaver: Accounts disabled by termination effective time; tokens revoked; shared secrets rotated.

JML events are audited through Microsoft ServiceNow and correlated in Azure Sentinel.

Annex A: A.5.18 – Access Rights

5.3 Account Standards

Every identity must be unique, traceable, and linked to a verified HR record or contract record.

Shared accounts are forbidden except for technical automation use cases with explicit CISO approval.

Service accounts must use managed identities or certificates with maximum 12-month lifetime.

Admin accounts must be separate from user accounts (dual-account model).

5.4 Group and Role Management

Entra ID Dynamic Groups control baseline access based on attributes (e.g., department, location).

Role assignments must map to approved Role-Based Access Control (RBAC) catalog entries.

RBAC catalog entries are maintained by Security Engineering and approved annually by each Business Unit Security Officer (BUSO).

High-risk roles (e.g., Global Administrator, Subscription Owner, Billing Administrator) are monitored continuously through PIM.

6 Authentication and Credential Management
6.1 Multi-Factor Authentication (MFA)

MFA is mandatory for all interactive logins to corporate, cloud, and third-party applications.

Supported methods: FIDO2 security keys (preferred), Windows Hello for Business, Microsoft Authenticator push.

SMS or voice MFA is deprecated and blocked except for temporary exceptions approved by Security Engineering.

MFA enforcement status is reported weekly to the CISO dashboard.

Annex A: A.5.17 – Authentication Information

6.2 Password Policy (Residual Use)

Where passwords remain necessary (non-SSO systems):

Minimum length: 14 characters.

Complexity: Not required (but entropy ≥ 64 bits measured via zxcvbn score).

Rotation: Annually or after compromise.

Storage: Only in Microsoft approved vault (e.g., Azure Key Vault or GitHub Secrets).

No reuse of last 24 passwords.

6.3 Token and Certificate Management

API and service authentication must use Azure Managed Identities or service principals with rotating credentials.

Certificates must be issued through Microsoft’s PKI and renewed automatically via Key Vault.

Expiring credentials generate automated tickets in ServiceNow 5 days before expiry.

6.4 Passwordless Initiative

All employees are enrolled in Microsoft’s passwordless program using FIDO2 or Authenticator App.

Target: 100 % passwordless logons by FY 2026.

6.5 Session Security

Idle session timeout: 15 minutes for high-risk apps; 30 minutes for standard apps.

Concurrent session limits enforced via Conditional Access Policies.

7 Authorization, RBAC and Segregation of Duties (SoD)
7.1 RBAC Model

Microsoft employs a tiered RBAC model integrated with Entra ID and Azure PIM:

Tier	Description	Example Roles
Tier 0	Enterprise root and identity control plane	Global Administrator, PIM Admin
Tier 1	Service operations and production control	Azure Subscription Owner, M365 Service Admin
Tier 2	Business and corporate systems	SharePoint Admin, Teams Admin
Tier 3	End-user and low-risk apps	Standard user roles

Role assignments must be documented in ServiceNow tickets with manager and owner approval.

Access changes require two-step approval and are retained for audit (≥ 1 year).

Azure PIM enforces time-bound elevation (max 8 hours) with mandatory MFA and justification.

7.2 SoD Matrix

Critical functions are segregated to prevent fraud or accidental damage:

Function	Conflicting Function	Control
Code Author	Code Deployer	Separate Azure DevOps roles
Finance Approver	Finance Initiator	ERP SoD matrix
Security Engineer	PIM Approver	Independent review
Data Exporter	Data Reviewer	Dual authorization required

SoD exceptions must be approved by the CISO and expire within 90 days.

All SoD matrices are reviewed quarterly by Internal Audit.

7.3 Access Reviews and Recertification

Quarterly reviews for Tier 0–1 roles.

Semi-annual reviews for Tier 2–3 roles.

Access owners attest through Entra ID Access Reviews; non-responses result in revocation after 10 days.

7.4 Logging and Evidence

All role changes, elevations, and approvals are logged in Azure Activity Logs and Microsoft Sentinel for retention ≥ 12 months.

Annex A: A.5.15 – A.5.18

8 Cloud and Production Access Controls
8.1 Environment Segregation

Production, Pre-production, and Development environments are segregated by subscription, network, and identity boundary.

Cross-environment role assignment is prohibited except through JIT PIM elevation.

Azure management groups define least-privilege policies for each environment.

Annex A: A.8.19 – Configuration Management

8.2 Access Mechanisms

Access to Azure production resources is via PIM-approved sessions only.

Direct SSH/RDP is prohibited; use Azure Bastion or Just-In-Time VM Access.

CLI and API operations require Entra ID authentication with MFA.

Service accounts for automation use Managed Identities or OIDC federation.

8.3 Change and Deployment Controls

All production changes must originate from Azure DevOps or GitHub Enterprise CI/CD pipelines with approved pull requests.

Direct manual deployment to production is forbidden.

Security Engineering validates release approvals for high-risk applications.

8.4 Secrets and Key Management

All secrets stored in Azure Key Vault or Defender for Cloud Apps Secret Store.

Secrets rotation interval: ≤ 90 days for shared keys; ≤ 24 hours for ephemeral tokens.

Key Vault access is audited and alerts sent for anomalies.

8.5 Monitoring and Incident Detection

Azure Monitor and Microsoft Sentinel collect and correlate logs from Azure, M365, and GitHub Enterprise.

Privileged access events trigger real-time alerts to Security Operations Center (SOC).

Monthly reporting of unauthorized access attempts and failed MFA events to CISO.

9 Data Access and Protection
9.1 Information Classification

Microsoft applies a four-tier Information Protection Classification Scheme (aligned with the Microsoft Information Protection program):

Classification Level	Definition	Typical Examples
Public	Approved for unrestricted disclosure.	Press releases, public product documentation.
Internal	Business information not intended for public release.	Internal project plans, intranet pages.
Confidential	Sensitive business or technical information that could impact operations if disclosed.	Source code, financial data, customer contracts.
Highly Confidential	Regulated or strategically sensitive information whose loss would cause serious harm.	Encryption keys, security incident records, M&A documents.
9.2 Access Control by Classification

Access to data is granted based on classification level and role requirements.

Confidential and Highly Confidential data require explicit business justification and manager approval.

Data stored in SharePoint Online, Teams, or Azure Storage must use Microsoft Information Protection (MIP) labels and sensitivity-based policies.

Azure RBAC and Conditional Access control access to Confidential data repositories.

Annex A: A.5.12 – Classification of Information

9.3 Data Loss Prevention (DLP)

Microsoft Purview DLP enforces data transfer restrictions for Outlook, Teams, and SharePoint.

Blocked actions include external sharing of unlabeled Confidential data and upload of sensitive files to unmanaged storage.

Exceptions require DPO approval and recording in ServiceNow.

9.4 Data Egress and Export

Confidential or Highly Confidential data exports must be logged and approved.

Automated telemetry and diagnostics data are pseudonymized per Microsoft Privacy Standard.

External data transfers to vendors use approved secure channels (Azure ExpressRoute, SFTP over TLS, etc.).

9.5 Data Retention and Deletion

Data retention follows Microsoft Data Lifecycle and Records Retention Policy.

Upon account termination, associated data is retained for 90 days and then purged automatically unless under legal hold.

10 Endpoint and Remote Access Security
10.1 Device Enrollment and Compliance

All corporate devices are enrolled in Microsoft Intune with MDM and EDR (Defender for Endpoint).

BYOD devices must be containerized using Microsoft Endpoint Manager and cannot store corporate data outside protected apps.

Compliance policies enforce disk encryption (BitLocker or FileVault), firewall enabled, Defender running, and OS patch ≤ 14 days old.

10.2 Conditional Access and Zero Trust

Conditional Access evaluates user risk, device compliance, and location before granting access.

Access from non-compliant devices or high-risk locations is blocked or requires step-up authentication.

Device posture telemetry integrated with Microsoft Defender for Cloud Apps.

10.3 Remote Access Controls

VPN access is phased out in favor of Zero Trust network access via Azure AD Application Proxy and Conditional Access.

Administrative remote sessions must use Privileged Access Workstations (PAWs).

Idle VPN sessions timeout after 15 minutes; audit logs retained for 12 months.

10.4 Endpoint Monitoring and Response

Defender for Endpoint monitors for compromise indicators and blocks risky executables.

Security Operations Center (SOC) investigates alerts 24/7 and links incidents to affected identities via Sentinel.

Annex A: A.8.1, A.8.7 – User Endpoint Devices and Security Monitoring

11 Third-Party and Vendor Access Management
11.1 Principles

Third-party access is a privilege, not a right. All external entities with logical or physical access to Microsoft systems must comply with this policy and Microsoft’s Supplier Security and Privacy Requirements (SPR).

11.2 Due Diligence and Onboarding

All vendors undergo risk assessment using Microsoft’s Supplier Risk Management Program (SRMP).

Access is granted only after DPA/NDA execution and security review.

Identity integration uses Entra B2B collaboration with MFA required.

Vendors receive time-boxed access (≤ 90 days) with automatic revocation.

11.3 Monitoring and Recertification

Vendor accounts reviewed monthly by Service Owners.

Inactive vendor accounts disabled after 30 days.

Vendor activities monitored in Microsoft Sentinel and audited quarterly by Vendor Risk Management.

11.4 Offboarding

Upon contract termination, vendor identities and access are revoked immediately.

Data returned or destroyed per contractual DPA clauses.

Annex A: A.5.19, A.5.23 – Third-Party Access and Supplier Relationships

12 Physical Access Controls
12.1 Datacenter Security

Microsoft datacenters operate under multi-layered physical security including fencing, CCTV, motion detection, and 24/7 security personnel.

Entry requires two-factor authentication (badge + biometric).

Visitors must be escorted and logged; visitor records retained ≥ 12 months.

Access zones classified as Public, Controlled, Restricted, and Highly Restricted.

12.2 Corporate Facilities

Office entry requires corporate badge with Active Directory-linked validation.

Access badges are disabled upon termination or extended leave.

Server rooms restricted to authorized IT and Facilities staff.

12.3 Environmental Controls

CCTV coverage retained ≥ 90 days.

Doors and rack locks integrated with Building Access System (BAS).

Security Engineering reviews physical access reports quarterly.

12.4 Incident Response

Physical security incidents (e.g., tailgating, lost badges) are logged in ServiceNow and investigated by Corporate Security.
Repeated violations lead to disciplinary action and mandatory training.

Annex A: A.7.1, A.7.2 – Physical and Environmental Security

13 Logging and Monitoring
13.1 Purpose

Logging and monitoring provide accountability, enable detection of unauthorized activity, and support incident response, audit, and forensic analysis.

13.2 Requirements

All systems and applications within scope must generate audit logs for authentication events, access changes, privilege elevations, and data access.

Logs must include user ID, source IP/device, action performed, timestamp (UTC), and result (success/failure).

Logs are ingested into Microsoft Sentinel and retained for at least 12 months (default) or per regulatory requirement.

Critical security events (failed MFA, break-glass use, SoD violation) must generate real-time alerts to the Security Operations Center (SOC).

SOC investigates and closes alerts within defined SLA (High = 1 hour, Medium = 4 hours, Low = 1 business day).

Log tampering or unauthorized deletion is prohibited and subject to disciplinary action.

13.3 Monitoring Scope
System / Domain	Monitoring Platform	Retention	Review Frequency
Entra ID / Azure AD	Sentinel, Defender for Identity	12 months	Daily alerts, Quarterly audit
Azure Subscriptions	Azure Monitor / Log Analytics	12 months	Continuous
M365 (Exchange, SharePoint, Teams)	Unified Audit Logs	12 months	Quarterly review
GitHub Enterprise	Sentinel integration via API	12 months	Quarterly
Endpoints (Intune, Defender)	MDM/EDR telemetry	6 months	Monthly review

Annex A: A.8.16 – Monitoring Activities

14 Access Reviews and Recertification
14.1 Frequency and Scope
Tier	Systems / Roles	Frequency	Owner
Tier 0	Global Admin, Root, PIM Approver	Quarterly	CISO / Security Engineering
Tier 1	Production Ops, Cloud Admins	Quarterly	System Owner
Tier 2	Corporate IT / M365 Admins	Semi-Annual	IT Operations
Tier 3	Standard Users	Annual	Managers
14.2 Process

Security GRC initiates review via Entra ID Access Reviews or ServiceNow task.

Owners receive access list with last login timestamps.

Owners attest validity (Y/N) for each user or role.

Revocations processed automatically for non-responses after 10 business days.

Results archived as audit evidence for ISMS records (retention ≥ 3 years).

14.3 Metrics and Reporting

Access Review Completion Rate (≥ 95 %)

Revoked Accesses Count (monthly trend)

SLA Adherence for Leaver revocation (100 % within 24 hours)

Annex A: A.5.18 – Access Rights Management

15 Exceptions, Violations and Sanctions
15.1 Exceptions

Exceptions must be documented in ServiceNow with: risk statement, compensating controls, owner, and expiry ≤ 90 days.

CISO or delegate must approve exceptions before implementation.

Expired exceptions trigger automatic notifications to Security Engineering for closure.

15.2 Violations and Enforcement

Unauthorized access or misuse of systems constitutes a policy violation.

Incidents will be investigated by Security and HR.

Sanctions range from retraining to termination of employment or contract.

Repeated non-compliance is escalated to CISO and Internal Audit.

15.3 Audit Findings and Corrective Actions

Audit non-conformities are tracked in the ISMS Corrective Action Register.

Remediation must be completed within agreed SLA (High = 30 days, Medium = 60 days, Low = 90 days).

Status reports submitted to ISMS Steering Committee.

Annex A: A.5.30 – Compliance with Policies and Standards

16 Training and Awareness
16.1 Mandatory Training

All employees and contractors must complete annual Information Security and Privacy training.

Privileged users (Global Admins, Developers, Engineers) require additional modules on PAM, SoD, and incident response.

Completion tracked via Microsoft Learn and HRIS.

16.2 Awareness Programs

Monthly security bulletins and phishing simulations.

Quarterly “Security in Practice” webinars run by Security Engineering.

Awareness metrics (quiz scores, simulation click rates) reported to CISO dashboard.

16.3 New Hire and Role Change Training

Mandatory orientation includes overview of access control responsibilities.

Engineers granted production access must complete PIM and RBAC training before activation.

Annex A: A.6.3 – Awareness, Education and Training

17 Appendices
17.1 Joiner-Mover-Leaver (JML) Workflow Summary
Stage	Trigger	System	Action	SLA
Joiner	HR Hire Event	Workday → Entra ID	Provision baseline roles via SCIM	24 h
Mover	Job Change	Workday → ServiceNow	Revoke obsolete access, add new roles	24 h
Leaver	Termination Event	Workday → IdP	Disable account, revoke tokens	Immediate

Evidence: System logs and ServiceNow tickets.
Annex A: A.5.18

17.2 PAM Workflow Summary
Step	Description	Control
1	User submits elevation request in PIM	A.5.15
2	Manager approval via workflow	A.5.18
3	MFA challenge and session recording	A.5.17
4	Auto revocation after max 8 hours	A.8.16
5	SOC review of recordings monthly	A.8.16

Evidence: PIM logs, approvals, session recordings.

17.3 Access Review Checklist (Excerpt)

Review Period: Quarterly

Reviewer: System Owner

Scope: All accounts with active roles and permissions above baseline.

Questions:

Is access still required?

Is the assigned role appropriate?

Has the user changed position or left the organization?

Are there any SoD violations?

18 Annex A Control Mapping (ISO / IEC 27001:2022)
Annex A Control	Control Title	Policy Section	Evidence Source
A.5.12	Classification of Information	§9	MIP labels, DLP rules
A.5.15	Access Control Policy	§1–7	ACP document, audit approval
A.5.16	Identity Management	§5	HRIS–IdP sync logs
A.5.17	Authentication Information	§6	MFA reports
A.5.18	Access Rights	§7, §14	Access review reports
A.5.19	Access to Source Code and Systems	§8	GitHub policies
A.5.23	Supplier Access Management	§11	Vendor risk reviews
A.5.30	Compliance with Policies	§15	Audit records
A.7.1	Physical Security Perimeter	§12	Access badges, visitor logs
A.7.2	Physical Entry Controls	§12	CCTV reports
A.8.1	User Endpoint Devices	§10	Intune compliance report
A.8.7	Protection Against Malware	§10	Defender alerts
A.8.9	Configuration Management	§8	Azure Policy snapshots
A.8.12	Data Leakage Prevention	§9	DLP alerts
A.8.16	Monitoring Activities	§13	SIEM dashboards
A.8.19	Change Management	§8	DevOps pipeline logs
A.8.28	Secure Coding and Deployment	§8	GitHub PR reviews

End of Access Control Policy
ISO / IEC 27001:2022 Access Control Policy — Microsoft Corporation (Demonstration Draft)
(ChatGPT5 via Morphic Core overlay v1.7.5b & Edward Levin)