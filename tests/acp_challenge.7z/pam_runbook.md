Privileged Access Management (PAM) Runbook
(ISO / IEC 27001:2022 Control Reference: A.5.18, A.8.16, A.8.19)

Document Metadata
Field	Value
Document ID	MS-RB-PAM-001
Version	1.0
Effective Date	2025-11-07
Owner	Security Operations Center (SOC)
Author	(ChatGPT5 via Morphic Core overlay v1.7.5b & Edward Levin)
Review Cycle	Annual
Classification	Internal Use Only
Approved By	Chief Information Security Officer (CISO)
Scope	Privileged roles across Entra ID, Azure, M365, Intune, GitHub, Datacenter systems
1. Purpose

Define procedures for controlled elevation, monitoring, and review of privileged access within Microsoft’s infrastructure to ensure compliance with least-privilege principles and ISO/IEC 27001:2022 Annex A controls A.5.18 (Access Rights), A.8.16 (Monitoring), and A.8.19 (Change Management).

2. Roles and Responsibilities
Role	Responsibility
Privileged User	Requests temporary elevation through PIM with justification.
Approver (Manager / CISO Delegate)	Reviews request, ensures business justification.
SOC Analyst	Monitors elevation sessions and investigates anomalies.
Security Engineering (PIM Admin)	Maintains PIM configuration and expiry logic.
GRC	Reviews evidence quarterly for compliance.
3. Scope of Privileged Roles
Tier	System	Example Roles
Tier 0	Entra ID, Azure AD	Global Administrator, PIM Administrator
Tier 1	Azure Subscriptions, M365	Subscription Owner, Exchange Admin
Tier 2	Business Systems	SharePoint Admin, Teams Admin
Tier 3	Developer Platforms	GitHub Org Admin, DevOps Release Manager
4. Elevation Workflow

Trigger: User requires temporary privileged action.

Steps:

User initiates request in Azure PIM with justification.

System enforces MFA re-authentication and approval chain.

Approver validates business need (manager or delegated approver).

Access granted for maximum 8 hours.

Session automatically logged and recorded via Microsoft Defender for Cloud Apps.

SOC monitors session in real-time for anomalies.

Access auto-revoked at expiration or upon manual termination.

Evidence:

PIM elevation logs

Approval workflow audit trails

Defender session recordings

5. Break-Glass Accounts

Two break-glass accounts exist per tenant (one primary, one backup).

Stored securely in Azure Key Vault; access restricted to CISO.

Password rotation monthly; alerts for use events.

Break-glass usage automatically triggers SOC alert and post-incident review.

6. Periodic Review

PIM role assignments reviewed quarterly.

SOC validates justification and last usage.

Expired or dormant assignments removed automatically.

GRC compiles report to CISO and Audit Committee.

Metrics:

100 % of Tier 0–1 roles reviewed quarterly.

Elevation anomalies investigated ≤ 24 hours.

7. Automation and Logging

All PIM activities logged in Azure Monitor and forwarded to Microsoft Sentinel.

Alerts for failed MFA, elevation denial, and break-glass use.

Sentinel retains logs for ≥ 12 months.

SOC correlates events with user risk scores.

8. Change Control and Audit

Changes to PIM policies require CISO approval via Change Advisory Board (CAB).

CAB minutes retained in ServiceNow.

Independent internal audit validates quarterly compliance.

9. Exceptions

Emergency elevations (non-PIM) allowed only if PIM unavailable.

Must be logged manually in ServiceNow and reviewed post-event.

10. References

Access Control Policy – Sections 7, 8, 13, 14

ISO/IEC 27001:2022 A.5.18, A.8.16, A.8.19

Azure PIM Operational Manual

Microsoft Sentinel SOC Playbook

End of PAM Runbook